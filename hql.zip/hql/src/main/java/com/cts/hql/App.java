package com.cts.hql;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;



public class App 
{
    public static void main( String[] args )
    {
       
        Configuration configuration = new Configuration().configure();
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		OrderItem order=new OrderItem(111,5,6,8,77,788.7f);
		 session.beginTransaction(); 
		 session.save(order);
		 session.getTransaction().commit();
		 System.out.println(order);
		/*
		 * String qry="select order.buyingPrice FROM OrderItem order"; Query
		 * q=session.createQuery(qry); List<OrderItem> ll=q.list();//will not class cast
		 * exception System.out.println(ll);
		 */
		 
		 
		/*
		 * Query query =
		 * session.createQuery("from OrderItem order where order.id = :id ");
		 * query.setParameter("id", 111); List<OrderItem> list=query.list();
		 * System.out.println(list);
		 */
		
		 
		/*
		 * OrderItem order=new OrderItem(); session.beginTransaction();
		 * session.save(order); session.getTransaction().commit(); order.setOrderId(6);
		 * String hql ="from OrderItem o where o.orderId = :orderId"; List result
		 * =session.createQuery(hql).setProperties(order).list();
		 * System.out.println(result);
		 */
		
		/*
		 * String hql = "from OrderItem o where o.orderId =?"; Query q =
		 * session.createQuery(hql); q.setParameter(0, 5); List result = q.list();
		 * System.out.println(result);
		 */
		 
		 
		session.close();
    }
}
