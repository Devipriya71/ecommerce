export class Addtocart{
    productid: number;
    quantity: number;
    total_price: number;
    
   

}