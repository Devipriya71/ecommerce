
import { Component } from '@angular/core';
import { Addcartitem } from './service';
import { Itemsearch } from './Itemsearch';
import { Addtocart } from './Addtocart';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'App4';
  cartitem:Addtocart[];
  constructor(private dataService: Addcartitem ) {
    console.log("constructor invoked");
   }

 /*Addtocart() {
    this.dataService.addItemById(1)
      .subscribe(items =>this.items=items );
  }*/
 
  Addtocart(buyerid: number) {
    this.articleService.createArticle(article).subscribe(
        article => {
          console.log(article);
        }
    );
  } 
