export class Itemsearch{
    productname: String;
    manufacturer: String;
    model: String;
    price: number;
    quantity: number;
   description: String;

}