package com.cts;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity

public class Transactions implements Serializable {
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int transaction_id;
	
	@ManyToOne
	@JoinColumn(name="buyer_id")
	private Buyer buyer_id;
	
	private int seller_id;
	private float amount;
	
	private String transaction_type;
	
	private Date date;
	
	private String remarks;
	
	
	public int getId() {
		return transaction_id;
	}
	public void setId(int id) {
		this.transaction_id = id;
	}
	
	
	
	public int getSeller_id() {
		return seller_id;
	}
	public void setSeller_id(int seller_id) {
		this.seller_id = seller_id;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
	public Transactions(int transaction_id, int seller_id, float amount, String transaction_type, Date date,
			String remarks) {
		super();
		this.transaction_id = transaction_id;
		
		this.seller_id = seller_id;
		this.amount = amount;
		this.transaction_type = transaction_type;
		this.date = date;
		this.remarks = remarks;
	}
	public Transactions() {
		
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Transactions [transaction_id=" + transaction_id + ", buyer_id=" + buyer_id + ", seller_id=" + seller_id
				+ ", amount=" + amount + ", transaction_type=" + transaction_type + ", date=" + date + ", remarks="
				+ remarks + "]";
	}
	
	


}
