package com.cts;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity

public class Subcategory {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int subcategory_id;
	
	private String subcategory_name;
	
	
	
	private String brief_details;
	
	private float gst;
	@ManyToOne
	@JoinColumn(name="category_id")
	private Category category_id;
	public int getSubcategory_id() {
		return subcategory_id;
	}
	public void setSubcategory_id(int subcategory_id) {
		this.subcategory_id = subcategory_id;
	}
	public String getSubcategory_name() {
		return subcategory_name;
	}
	public void setSubcategory_name(String subcategory_name) {
		this.subcategory_name = subcategory_name;
	}
	public String getBrief_details() {
		return brief_details;
	}
	public void setBrief_details(String brief_details) {
		this.brief_details = brief_details;
	}
	public float getGst() {
		return gst;
	}
	public void setGst(float gst) {
		this.gst = gst;
	}
	public Subcategory() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Subcategory(int subcategory_id, String subcategory_name, String brief_details, float gst) {
		super();
		this.subcategory_id = subcategory_id;
		this.subcategory_name = subcategory_name;
		this.brief_details = brief_details;
		this.gst = gst;
	}
	
	
	
	
	


}
