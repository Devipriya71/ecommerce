package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.Cart;
import com.cts.service.Cartservice;

@RestController
public class Cartcontroller {
	

	/* private final BuyerRepository repository; */
	@Autowired
	private Cartservice cartservice;
	
	
	@RequestMapping("/cartitems")    
	public List<Cart> getAllItem()  
	{    
	return cartservice.getAllCart();    
	} 
	
	// post method to insert new buyer details
	
	  @PostMapping("/buyerslist/{buyerId}/cartitems") 
	  public Cart newCartItems(@RequestBody Cart newCart, @PathVariable ("buyerId")Integer buyerId) { 
		  System.out.println("in cartitemcontroller");
		  Cart cartitem = cartservice.addCart(newCart, buyerId); 
		  return cartitem;
	 }
	 
	
	
	@GetMapping("")
	
	
	@RequestMapping("/cart")
	public String sayHi() {
		return "Hi Cart-Items";
	}

}
