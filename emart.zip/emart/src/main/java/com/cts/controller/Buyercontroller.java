package com.cts.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.Buyer;
import com.cts.service.Buyerservice;


@RestController
public class Buyercontroller {
	
	@Autowired
	private Buyerservice buyerservice;
	
	@RequestMapping("/buyers")    
	public List<Buyer> getAllUser()  
	{    
	return buyerservice.getAllBuyers();    
	}
	
	@PostMapping("/buyerslist")
	public Buyer newBuyer(@RequestBody Buyer newBuyer) {
		Buyer buyer = buyerservice.addBuyer(newBuyer);
		System.out.println("hi");
		return buyer;
	}
	
	@GetMapping("/buyerslist/{id}")
	public Buyer getBuyer(@PathVariable(value="id") Integer buyerId) {
		Optional<Buyer> showBuyer = buyerservice.getBuyer(buyerId);
		return showBuyer.get();
	}
	
	@DeleteMapping("/buyerslist/{buyerId}")
	private void deleteBuyer(@PathVariable("buyerId") int buyerId) {
		buyerservice.deleteBuyer(buyerId);
	}
	
	@PutMapping("/buyerslist/{id}")
	private Buyer updateBuyer(@RequestBody Buyer buyer, String emailId, String date,@PathVariable Integer id) {
		buyerservice.saveOrUpdate(buyer, id, emailId, date);
		return buyer;		
	}
	
@GetMapping("")
	
	
	@RequestMapping("/buyerin")
	public String sayHi() {
		return "Hi Buyer";
	}

}
