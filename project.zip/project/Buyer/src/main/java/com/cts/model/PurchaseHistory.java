package com.cts.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;

@Entity
public class PurchaseHistory {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="purchase_history_id")
	private Integer id;
	
	@ManyToOne
	@JoinColumn(name = "buyer_id")
	private BuyerInfo buyer;
	
	
	@ManyToOne
	@JoinColumn(name="transaction_id")
	private Transactions transactionId;
	
	private Integer itemId;
	private float price;
	private Integer itemQuantity;
	
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date date;
	
	private String remarks;

	
	public PurchaseHistory( BuyerInfo buyer, Transactions transactionId, Integer itemId, float price,
			Integer itemQuantity, Date date, String remarks) {
		super();
		
		this.buyer = buyer;
		this.transactionId = transactionId;
		this.itemId = itemId;
		this.price = price;
		this.itemQuantity = itemQuantity;
		this.date = date;
		this.remarks = remarks;
	}

	public PurchaseHistory() {
		super();
	}

	public BuyerInfo getBuyer() {
		return buyer;
	}

	public void setBuyer(BuyerInfo buyer) {
		this.buyer = buyer;
	}

	public Transactions getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Transactions transactionId) {
		this.transactionId = transactionId;
	}

	public Integer getItemId() {
		return itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}

	public Integer getItemQuantity() {
		return itemQuantity;
	}

	public void setItemQuantity(Integer itemQuantity) {
		this.itemQuantity = itemQuantity;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "PurchaseHistory [id=" + id + ", buyer=" + buyer + ", transactionId=" + transactionId + ", itemId="
				+ itemId + ", price=" + price + ", itemQuantity=" + itemQuantity + ", date=" + date + ", remarks="
				+ remarks + "]";
	}

	
	
	

}
