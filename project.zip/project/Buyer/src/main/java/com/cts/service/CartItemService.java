package com.cts.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.BuyerInfo;
import com.cts.model.CartItems;
import com.cts.model.Transactions;
import com.cts.model.PurchaseHistory;
import com.cts.repository.BuyerRepository;
import com.cts.repository.CartItemRepository;
import com.cts.repository.PurchaseRepository;
import com.cts.repository.Transactionrepository;


@Service
public class CartItemService {
	
	@Autowired
	private CartItemRepository cartItemRepository;
	
	@Autowired
	private BuyerRepository buyerRepository;
	
	@Autowired
	private PurchaseRepository purchaseRepository;
	
	@Autowired
	private Transactionrepository transactionRepository;
	
	

	public List<CartItems> getAllCartItems() {
		
		List<CartItems> allCartItems = new ArrayList<CartItems>();
		cartItemRepository.findAll().forEach(allCartItems::add);
		
		return allCartItems;
	}

	public CartItems addCartItem(CartItems newCartItems, Integer buyerId) {
		
		System.out.println("In service");
		Optional<BuyerInfo> buyer = buyerRepository.findById(buyerId);
		newCartItems.setBuyer(buyer.get());
		return cartItemRepository.save(newCartItems);
		
	}
	
	public List<CartItems> getCartItems( Integer buyerId) {
	
		
		return cartItemRepository.getCartItemByBuyerId(buyerId);
	}
	
	public CartItems incDecItem(CartItems newCartItem) {
		System.out.println("In cart qty update service");
		
		Optional<CartItems> cartItem = cartItemRepository.findById(newCartItem.getCartItemId());
		System.out.println(cartItem.get());
		if(cartItem.isPresent()) {
			CartItems updatedCartItem = cartItem.get();
			System.out.println(newCartItem.getQuantity());
			updatedCartItem.setQuantity(newCartItem.getQuantity());
			System.out.println(newCartItem.getQuantity());
			return cartItemRepository.save(updatedCartItem);
			
		}
		return null;
	}

	public void deleteCartItem(Integer carItemId) {
		
		
		cartItemRepository.deleteById(carItemId);
		
		
	}
	
	 public void emptyCart(int buyid)
	    {
		 cartItemRepository.emptyCart(buyid);
	    	
	    }

	public String checkOut(Transactions tran, int buyerid) {
		BuyerInfo buyer=buyerRepository.getOne(buyerid);
		System.out.println(buyer);
		tran.setBuyer(buyer);

		float sum=0;
		List<CartItems> shcart1=cartItemRepository.byid(buyerid);
		for(int i=0;i<shcart1.size();i++)
		{
			PurchaseHistory phis=new PurchaseHistory();
			CartItems shcartitems=shcart1.get(i);
			int size=shcartitems.getQuantity();
			float cost=shcartitems.getPrice();
			phis.setPrice(cost);
			phis.setItemQuantity(size);
			phis.setBuyer(buyer);
			sum=sum+cost;
			System.out.println(phis);
			
			cartItemRepository.deleteById(shcartitems.getCartItemId());
			purchaseRepository.save(phis);
			
			
		}
		tran.setTotalcost(sum);
		System.out.println(tran);
		transactionRepository.save(tran);	
		return "Transaction completed succeccfully";
	}
	  
	
	
	
	
}