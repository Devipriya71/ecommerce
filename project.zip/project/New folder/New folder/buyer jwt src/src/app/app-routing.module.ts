import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BuyerSignupComponent } from './buyer-signup/buyer-signup.component';
import { HomeComponent } from './home/home.component';
import { CartComponent } from './cart/cart.component';
import { BuyerLoginComponent } from './buyer-login/buyer-login.component';
import { ShowproductsComponent } from './showproducts/showproducts.component';
import { CheckoutComponent } from './checkout/checkout.component';


const routes: Routes = [
  { path: 'usersignup', component: BuyerSignupComponent },
  { path: 'userlogin', component: BuyerLoginComponent },
  { path: 'home', component: HomeComponent },
  { path: 'products', component: ShowproductsComponent },
  { path: 'cart', component: CartComponent },
  { path: 'checkout', component: CheckoutComponent },
  { path: '', component: ShowproductsComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
