package com.cts.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.cts.model.Seller;
import com.cts.repository.AddressRepository;
import com.cts.repository.SellerRepository;



@Service
public class SellerService {
	
	@Autowired
	private SellerRepository sellerRepository;
	
	@Autowired 
	private AddressRepository addressRepository;
	
	public List<Seller> getAllSellers(){
		List<Seller> sellerRecord = new ArrayList<Seller>();
		sellerRepository.findAll().forEach(sellerRecord::add);    
		return sellerRecord;
	}
	
	// add new seller details
	public Seller addSeller(Seller seller) {
		addressRepository.save(seller.getPostalAddress());
		return sellerRepository.save(seller);
		
	}
	
	
	// getById method
	public Optional<Seller> getSeller(@PathVariable Integer sellerId) {
		return sellerRepository.findById(sellerId);
	}
	
	// Delete Buyer 
	public void deleteSeller(Integer sellerId) {
		sellerRepository.deleteById(sellerId);
	}
	
	// Update Buyer
	public Seller saveOrUpdate(Seller seller, Integer id, String emailId, Date date ) {
		
		Optional<Seller> buyer = sellerRepository.findById(id);
		seller.setEmailId(emailId);
		return sellerRepository.save(seller);
		
		
		
		
	}
	
}
