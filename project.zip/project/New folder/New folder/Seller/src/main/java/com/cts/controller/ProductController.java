package com.cts.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Product;
import com.cts.service.ProductService;



@RestController
@CrossOrigin("*")
public class ProductController {
	
	
	@Autowired
	private ProductService productService;
	
	
	// get all buyer
	@RequestMapping("/products")    
	public List<Product> getAllProducts()  
	{    
	return productService.getAllProducts();    
	} 
	
	// insert new product details
	@PostMapping("/product/{sellerId}")
	public Product newProduct(@RequestBody Product newProduct, @PathVariable ("sellerId")Integer sellerId) {
		Product product = productService.addProduct(newProduct, sellerId);
		return product;
	}
	
	
	 @GetMapping("/getMatchItems/{proname}") 
	  public List<Product> searchProduct(@PathVariable("proname") String productname){ 
		  return productService.searchProduct(productname); }
	 
	
	
	
}
