import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CartModel } from '../models/cart.model';
import { ShopCart } from '../models/cart.model';

import { Observable } from 'rxjs';
import { CartComponent } from '../cart/cart.component';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor(private http:HttpClient) { }

  private baseUrl = "http://localhost:8081";

  public showCartItems():Observable<any> {
    return this.http.get(this.baseUrl+'/3/getcartitems');
  }

  public update(cart: CartModel):Observable<any> {
    return this.http.put<CartComponent>(this.baseUrl+'/cartitem/3', cart);
  }
  private baseUrl1 = "http://localhost:8081/deletecartitem";
 //private baseUrl1="http://localhost:8989/mentorportal/buyer/deletecartitem";

  deleteCartItem() :Observable<any>{
    return this.http.delete(`http://localhost:8081/deletecartitem/40`);
    //return this.http.delete(`http://localhost:8081/deletecartitem`);

  }

  emptyCart() :Observable<any>{
    console.log("hi");
   return this.http.delete(`http://localhost:8081/emptyCart/2`);
   // return this.http.delete(`http://localhost:8081/emptyCart`);

  }


  checkOutCart(checkout:ShopCart) :Observable<any>
  {
    console.log("hello");
    return this.http.post(`http://localhost:8081/checkout/3`,checkout);
    //return this.http.post(`http://localhost:8081/checkout`,checkout);

 
  }

}
