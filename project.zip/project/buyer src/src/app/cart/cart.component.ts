import { Component, OnInit } from '@angular/core';
import { CartModel } from '../models/cart.model';
import { ShopCart } from '../models/cart.model';

import { Router } from '@angular/router';
import { CartService } from '../service/cart.service';
import { ProductsModel } from '../models/products.model';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})


export class CartComponent implements OnInit {

  displayCart:ShopCart[];
  product: ProductsModel[];
  cartItems : CartModel[];
  item : CartModel;
  scart : ShopCart =new ShopCart();
  fare:number;
  totalPrice:number=0;
  constructor(private router: Router, private cartService: CartService ) { }
  
  ngOnInit(): void {
    this.fare=100;
    this.cartService.showCartItems().subscribe( displayCart => this.displayCart=displayCart);

    this.showCartItems();
  }

  showCartItems(): void {
    //console.log(this.buyer.emailId);
    this.cartItems
    this.cartService.showCartItems()
        .subscribe(cartItem => {this.cartItems = cartItem;
          this.totalPrice=0;
          this.cartItems.forEach(element => {
          
           
            this.totalPrice = this.totalPrice + element.price*element.quantity
           
          });
          console.log("hi"+this.totalPrice)
        }
          
            
          );
  }

  
  increase(cart : CartModel) {
    cart.quantity += 1;
    this.cartService.update(cart).subscribe(item => {this.item = item;
    this.showCartItems();
    });
  }

  decrease(cart : CartModel) {
    if(cart.quantity == 0){
      return alert("Can't be Decrease")
    }
    cart.quantity -= 1;
    this.cartService.update(cart).subscribe(item => {this.item = item;
    this.showCartItems();
    });
    
  }

  // totalPrice(){
  //   var total =0;
  //   this.cartItems.forEach(element => {
  //     console.log("total p 1 "+total)
  //       // total +=;
  //   });
  //   console.log("total p "+total)
  //   return total;
  // }
  
  

 /* deleteCartItem(cart: CartModel): void {
    console.log("hii");
    this.cartService.deleteCartItem(cart.cartItemId)
      .subscribe( data => {
        this.cartItems = this.cartItems.filter(u => u !== cart);
        this.showCartItems();
        alert(cart);
      })
  };*/

  onSubmit()
  {
    this.cartService.deleteCartItem().subscribe( displayCart => this.displayCart=displayCart);
    alert("Item deleted");
  }

  onSub()
  {
    this.cartService.emptyCart().subscribe( displayCart => this.displayCart=displayCart);
  }

  onCheck(checkout:ShopCart)
  {
    this.cartService.checkOutCart(checkout).subscribe( newview => this.cartService=newview);
  }

}
