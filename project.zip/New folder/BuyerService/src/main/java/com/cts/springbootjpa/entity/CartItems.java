package com.cts.springbootjpa.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.springframework.boot.autoconfigure.web.ResourceProperties.Strategy;

@Entity
public class CartItems {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer cartItemId;
	private Integer itemId;
	private Integer quantity;
	private Float price;
	@ManyToOne
	private BuyerDetails buyerDetailsId;
	public CartItems() 
	{ 
		
	}
	public CartItems(Integer cartItemId, Integer itemId, Integer quantity,Float price, BuyerDetails buyerDetails) {
		super();
		this.cartItemId = cartItemId;
		this.itemId = itemId;
		this.quantity = quantity;
		this.price=price;
		this.buyerDetailsId = buyerDetailsId;
	}
	public Integer getCartItemId() {
		return cartItemId;
	}
	public void setCartItemId(Integer cartItemId) {
		this.cartItemId = cartItemId;
	}
	public Integer getItemId() {
		return itemId;
	}
	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public BuyerDetails getBuyerDetailsId() {
		return buyerDetailsId;
	}
	public void setBuyerDetailsId(BuyerDetails buyerDetailsId) {
		this.buyerDetailsId = buyerDetailsId;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "CartItems [cartItemId=" + cartItemId + ", itemId=" + itemId + ", quantity=" + quantity + ", price="
				+ price + ", buyerDetailsId=" + buyerDetailsId + "]";
	}
	

}
