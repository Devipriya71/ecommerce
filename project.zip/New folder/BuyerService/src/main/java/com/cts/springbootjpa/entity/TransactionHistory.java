package com.cts.springbootjpa.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class TransactionHistory {
	@Id
	@GeneratedValue( strategy = GenerationType.AUTO)
	private int transactionId;
	private String transactionType;
	@Temporal(TemporalType.DATE) 
	@JsonFormat(pattern = "dd-mm-yyyy")
	private Date dateTime;
	private String remarks;
	private float price;
	@ManyToOne
	@JoinColumn(name="buyer_details_ID")
	private BuyerDetails buyerdetails;
	public TransactionHistory() 
	{ 
		
	}
	public TransactionHistory(int transactionId, String transactionType, Date dateTime, String remarks,
			BuyerDetails buyerdetails) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.dateTime = dateTime;
		this.remarks = remarks;
		this.price=price;
		this.buyerdetails = buyerdetails;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public Date getDateTime() {
		return dateTime;
	}
	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public BuyerDetails getBuyerdetails() {
		return buyerdetails;
	}
	public void setBuyerdetails(BuyerDetails buyerdetails) {
		this.buyerdetails = buyerdetails;
	}
	
	
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "TransactionHistory [transactionId=" + transactionId + ", transactionType=" + transactionType
				+ ", dateTime=" + dateTime + ", remarks=" + remarks + ", price=" + price + ", buyerdetails="
				+ buyerdetails + "]";
	}
	

}
