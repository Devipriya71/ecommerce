package com.cts.springbootjpa.service;

import java.util.List;
import java.util.Optional;

import com.cts.springbootjpa.entity.BuyerDetails;
import com.cts.springbootjpa.entity.CartItems;
import com.cts.springbootjpa.entity.Category;
import com.cts.springbootjpa.entity.PurchaseHistory;
import com.cts.springbootjpa.entity.Sub_Category;
import com.cts.springbootjpa.entity.TransactionHistory;

public interface Iservice {
	//Buyers
    List<BuyerDetails> getAll();
	BuyerDetails add(BuyerDetails buyerdetails);
	BuyerDetails getUser(int id);
	BuyerDetails updateBuyer(BuyerDetails buyerdetails,int id);
	
	//Items
	List<CartItems> getAllItems();
	CartItems addcart(CartItems cartItems,int id);
	CartItems getItem(int id);
	CartItems updateItem(CartItems cartItems,int id);
	void  deleteItem(int id);
	void  deleteAllItem();
	
	
	//Transactions
	List<TransactionHistory> getAllTransaction();
	TransactionHistory addcartItems(TransactionHistory transactonhistory,int id);
	TransactionHistory getTransaction(int id);
	TransactionHistory updateTransaction(TransactionHistory transactionhistory,int id);
	
	
	//purchasehistory
	List<PurchaseHistory> getPurchase();
	PurchaseHistory addPurchase(PurchaseHistory purchasehistory,int id,int ids);
	PurchaseHistory getpurchase(int id);
	PurchaseHistory updatePurchase(PurchaseHistory purchasehistory,int id);
	
	
}
