package com.cts.springbootjpa.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.springbootjpa.Dao.CategoryDao;
import com.cts.springbootjpa.Dao.Idao;
import com.cts.springbootjpa.Dao.ItemsDao;
import com.cts.springbootjpa.Dao.PurchaseDao;
import com.cts.springbootjpa.Dao.TransactionDao;
import com.cts.springbootjpa.entity.BuyerDetails;
import com.cts.springbootjpa.entity.CartItems;
import com.cts.springbootjpa.entity.Category;
import com.cts.springbootjpa.entity.PurchaseHistory;
import com.cts.springbootjpa.entity.TransactionHistory;


@Service
public class UserService implements Iservice {
    @Autowired
    private Idao dao;
    @Autowired
    private ItemsDao itemsDao;
    @Autowired
    private TransactionDao transactionDao;
    @Autowired
    private PurchaseDao purchaseDao;
    
    
     //Buyers
	  @Override 
	  public List<BuyerDetails> getAll() {
	  
	  return dao.findAll() ; 
	  }
	 @Override
	  public BuyerDetails add(BuyerDetails buyerdetails) {
		
		return dao.save(buyerdetails);
	 }
	 @Override
	 public BuyerDetails getUser(int id) {
		return dao.findOne(id);
	  }
	 @Override
	 public BuyerDetails updateBuyer(BuyerDetails buyerdetails,int id) {
		BuyerDetails buyerDetails1=dao.findOne(id);
		if(buyerDetails1!=null)
		{   
			int buyerId=buyerdetails.getBuyerID();
			String password=buyerdetails.getPassword();
			String EmailId=buyerdetails.getEmailId();
			Date createddate=buyerdetails.getCreatedDate();
			long mobileNo=buyerdetails.getMobileNumber();
			System.out.println("enter into if");
			buyerDetails1.setBuyerID(buyerId);
			buyerDetails1.setPassword(password);
			buyerDetails1.setEmailId(EmailId);
			buyerDetails1.setCreatedDate(createddate);
			buyerDetails1.setMobileNumber(mobileNo);
			System.out.println(buyerDetails1.getEmailId());
			
			
		}
		else 
		{ 
			
		}
	return dao.save(buyerDetails1);
	
	
	}
     
	 
	 
	//Items
	@Override
	public List<CartItems> getAllItems() {
		return itemsDao.findAll();
 	
	}
     @Override
	public CartItems addcart(CartItems cartItems,int id) {
		BuyerDetails buyerdetails=dao.findOne(id);
		cartItems.setBuyerDetails(buyerdetails);
		return itemsDao.save(cartItems);
	}
	@Override
	public CartItems getItem(int id) {
		return itemsDao.findOne(id);
	}
	@Override
	public CartItems updateItem(CartItems cartItems, int id) {
		CartItems cartItems1=itemsDao.findOne(id);
		if(cartItems1!=null)
		{
			 int cartItemId=cartItems.getCartItemId();
			 int itemId=cartItems.getItemId();
			 int quantity=cartItems.getQuantity();
			 cartItems1.setCartItemId(cartItemId);
			 cartItems1.setItemId(itemId);
			 cartItems1.setQuantity(quantity);
			
		}
		else
		{
			
		}
		return itemsDao.save(cartItems1);
	}
	@Override
	public void deleteItem(int id) {
		 itemsDao.delete(id);	
	}
	@Override
	public void deleteAllItem() {
		itemsDao.deleteAll();
	}

	
	
	//Transactions
	@Override
	public List<TransactionHistory> getAllTransaction() {
		return transactionDao.findAll();
	}
	@Override
	public TransactionHistory addcartItems(TransactionHistory transactonhistory, int id) {
        BuyerDetails buyerdetails = dao.findOne(id);
        transactonhistory.setBuyerdetails(buyerdetails);
		return transactionDao.save(transactonhistory);
	}
	@Override
	public TransactionHistory getTransaction(int id) {
		return transactionDao.findOne(id);
	}
	@Override
	public TransactionHistory updateTransaction(TransactionHistory transactionhistory, int id) {
		TransactionHistory transactionhistory1 = transactionDao.findOne(id);
		if(transactionhistory1!=null)
		{
			int transactionId=transactionhistory.getTransactionId();
			String transactionType=transactionhistory.getTransactionType();
			Date dateTime=transactionhistory.getDateTime();
			String remarks=transactionhistory.getRemarks();
			transactionhistory1.setTransactionId(transactionId);
			transactionhistory1.setTransactionType(transactionType);
			transactionhistory1.setDateTime(dateTime);
			transactionhistory1.setRemarks(remarks);
		}
		else 
		{
			
		}
		
		return transactionDao.save(transactionhistory1);
	}
	@Override
	public PurchaseHistory addPurchase(PurchaseHistory purchasehistory, int id,int ids) {
		BuyerDetails buyerDetails = dao.findOne(id);
		TransactionHistory transactionHistory = transactionDao.findOne(ids);
		purchasehistory.setBuyerdetails(buyerDetails);
		purchasehistory.setTransactionhistory(transactionHistory);
		return purchaseDao.save(purchasehistory);
	}
	@Override
	public List<PurchaseHistory> getPurchase() {
		return purchaseDao.findAll();
	}
	@Override
	public PurchaseHistory getpurchase(int id) {	
		return purchaseDao.findOne(id);
	}
	@Override
	public PurchaseHistory updatePurchase(PurchaseHistory purchasehistory, int id) {
		PurchaseHistory purchasehistory1 = purchaseDao.findOne(id);
		if(purchasehistory1!=null)
		{
			int purchaseHistoryId=purchasehistory.getPurchaseHistoryId();
			int itemId=purchasehistory.getItemId();
			Date dateTime=purchasehistory.getDateTime();
			int numberOfItems=purchasehistory.getNumberOfItems();
			String remarks=purchasehistory.getRemarks();
			purchasehistory1.setDateTime(dateTime);
			purchasehistory1.setItemId(itemId);
			purchasehistory1.setNumberOfItems(numberOfItems);
			purchasehistory1.setRemarks(remarks);
			purchasehistory1.setPurchaseHistoryId(purchaseHistoryId);
		}
		else 
		{
			
		}
		
		return purchaseDao.save(purchasehistory1);
	}


	
	


	

}
