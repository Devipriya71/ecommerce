export class Cart {
    
itemId:number;
 quantity:number=1;
 price:number;

}

export class ViewCart{

cartId:number;
itemId:number;
quantity:number;


}





