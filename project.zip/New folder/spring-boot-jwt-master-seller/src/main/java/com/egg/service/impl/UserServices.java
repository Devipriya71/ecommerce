package com.egg.service.impl;

import java.util.Arrays;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.ItemsDao;
import com.egg.dao.SellerDao;
import com.egg.model.Items;
import com.egg.model.Seller;
import com.egg.service.Iseller;



@Service(value="userService")
public class UserServices implements UserDetailsService,Iseller {
	

	
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	@Autowired
	private SellerDao dao;
	
	@Autowired
	private ItemsDao itemsdao;
	
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	Seller seller = dao.findByUsername(username);
		if(seller == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(seller.getUsername(), seller.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}
	
	@Override
	public List<Seller> getAll() {
		
		return dao.findAll();
	}
	@Override
	public Seller addSeller(Seller seller) {
		seller.setPassword(bcryptEncoder.encode(seller.getPassword()));
		return dao.save(seller);
	}
	@Override
	public Seller getSeller(int id) {
	
		Optional<Seller> seller = dao.findById(id);
		return seller.get();
	}
	@Override
	public Seller updateSeller(Seller seller, int id) {
		Optional<Seller> seller1 = dao.findById(id);
		
//		Seller seller1 = dao.getOne(id);
		if (seller1 != null) {

			//  int sellersellerid=seller.getSellerid(); 
			  String username=seller.getUsername(); 
			  String password=seller.getPassword(); 
			  String emailId=seller.getEmailId(); 
			  String address=seller.getAddress();
			  String companyname=seller.getCompanyname();
			  String briefaboutcompany=seller.getBriefaboutcompany();
			  String website=seller.getWebsite();
			  Double gstin=seller.getGstin();
			  String contactnumber=seller.getContactnumber();
			  System.out.println("enter into info"); 
			//  seller1.get().setSellerid(sellersellerid);
			  seller1.get().setUsername(username); 
			  seller1.get().setPassword(password);
			  seller1.get().setEmailId(emailId); 
			  seller1.get().setAddress(address);
			  seller1.get().setBriefaboutcompany(briefaboutcompany);
			  seller1.get().setContactnumber(contactnumber);
			  seller1.get().setCompanyname(companyname);
			  seller1.get().setGstin(gstin);
			  seller1.get().setWebsite(website);
			 
			 

		} else {
			
		}
		
	return dao.save(seller);
	}
	
	@Override
	public Seller findOne(String username) {
		
		return dao.findByUsername(username);
	}
	
	
	
	
	
	// Items Service
	@Override
	public List<Items> getAllItems() {
		
		return itemsdao.findAll();
	}
	@Override
	public Items addItems(Items items) {
	
		return itemsdao.save(items);
	}

	@Override
	public Items getProduct(int id) {
		
		Optional<Items> items= itemsdao.findById(id);
		return items.get();
	}
	@Override
	public Items updateItems(Items items, int id) {
		
		
		Optional<Items> items1=itemsdao.findById(id);
		if(items1!=null) {
			Double itemcost=items.getItemCost();
			String itemname=items.getItemName();
			String itemdescription=items.getItemDescription();
			int quantity=items.getQuantity();
			String model=items.getModel();
			String manfacture=items.getManfacture();
			int sellerid=items.getSellerid();
			int categoryid=items.getCategoryid();
			int subcategoryid=items.getSubcategoryid();
			
			  System.out.println("enter into info");
			  items1.get().setItemCost(itemcost);
			  items1.get().setItemName(itemname);
			  items1.get().setItemDescription(itemdescription);
			  items1.get().setQuantity(quantity);
			  items1.get().setModel(model);
			  items1.get().setManfacture(manfacture);
			  items1.get().setSellerid(sellerid);
			  items1.get().setCategoryid(subcategoryid);
			  items1.get().setSubcategoryid(subcategoryid);
			  
		}
		else {
			
		}
		
		return itemsdao.save(items);
	}
	@Override
	public void deleteById(Integer itemId) {
		Optional<Items> itemid = itemsdao.findById(itemId);
		if(itemid.isPresent())
		{
			itemsdao.deleteById(itemId);
			System.out.println("Deleted the item"+itemid);
	}
		else {
			
		}
		System.out.println("Deleted the item"+itemid);
	
	}

	
	
	
}




