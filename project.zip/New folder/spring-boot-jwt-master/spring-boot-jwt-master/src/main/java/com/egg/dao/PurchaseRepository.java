package com.egg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.egg.model.PurchaseHistory;



public interface PurchaseRepository extends JpaRepository<PurchaseHistory, Long>{

}
