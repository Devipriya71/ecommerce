import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ProductsModel } from '../models/products.model';
import { CartModel } from '../models/cart.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient) { }

  private baseUrl = "http://localhost:8182";
  private baseUrl1 = "http://localhost:8080";

  public showAllProducts():Observable<any> {
    return this.http.get(this.baseUrl+'/products');
  }

  public addToCart(cart: CartModel):Observable<any> {
    console.log(cart);
    return this.http.post(this.baseUrl1+'/buyer/addcartitems/3', cart);
  }

  
}
