package com.cts.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.BuyerInfo;
import com.cts.service.BuyersInfoService;
import com.cts.repository.BuyerRepository;

@RestController
@CrossOrigin("*")
public class BuyerController {
	
	
	@Autowired
	private BuyersInfoService buyerservice;
	
	
	// get all buyers
	@RequestMapping("/buyers")    
	public List<BuyerInfo> getAllUser()  
	{    
	return buyerservice.getAllBuyers();    
	} 
	
	// insert buyer details
	@PostMapping("/buyersinfo")
	public BuyerInfo newBuyerInfo(@RequestBody BuyerInfo newBuyerInfo) {
		BuyerInfo buyerInfo = buyerservice.addBuyer(newBuyerInfo);
		return buyerInfo;
	}
	
	// getById method
	@GetMapping("/buyersinfo/{id}")
	public BuyerInfo getBuyerInfo(@PathVariable(value="id") Integer buyerId) {
		Optional<BuyerInfo> showBuyer = buyerservice.getBuyer(buyerId);
		return showBuyer.get();
	}
	
	// Delete Buyer
	@DeleteMapping("/buyersinfo/{buyerId}")
	private void deleteBuyerInfo(@PathVariable("buyerId") Integer buyerId) {
		buyerservice.deleteBuyersInfo(buyerId);
	}
	
	// Update BuyersInfo
	@PutMapping("/buyersinfo/{id}")
	private BuyerInfo updateBuyersInfo(@RequestBody BuyerInfo buyersInfo, String emailId, Date date,@PathVariable Integer id) {
		buyerservice.saveOrUpdate(buyersInfo, id, emailId, date);
		return buyersInfo;		
	}                                                                          
	
	
	
	}

