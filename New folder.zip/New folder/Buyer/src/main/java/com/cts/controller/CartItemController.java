package com.cts.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.BuyerInfo;
import com.cts.model.CartItems;
import com.cts.model.PurchaseHistory;
import com.cts.model.Transactions;
import com.cts.service.BuyersInfoService;
import com.cts.service.CartItemService;
import com.cts.service.PurchaseService;
import com.cts.repository.BuyerRepository;

@RestController
@CrossOrigin("*")
public class CartItemController {
	
	
	@Autowired
	private CartItemService cartItemService;
	
	@Autowired
	private PurchaseService purchaseService;
	
	
	// get all buyer
	@RequestMapping("/cartitems")    
	public List<CartItems> getAllItem()  
	{    
	return cartItemService.getAllCartItems();    
	} 
	
	//  insert new cartitem details
	
	  @PostMapping("/buyer/addcartitems/{buyerId}") 
	  public CartItems newCartItems(@RequestBody CartItems newCartItems, @PathVariable ("buyerId")Integer buyerId) { 
		  System.out.println("in cartitemcontroller");
		  CartItems cartitem = cartItemService.addCartItem(newCartItems, buyerId); 
		  return cartitem;
	 }
	 
	  
	// getById method
		
	   @GetMapping("/{buyerId}/getcartitems") 
	   public List<CartItems> cartItemByBuyerId(@PathVariable(value="buyerId") Integer buyerId) {
		return cartItemService.getCartItems(buyerId);
			
	  }
	   
	   
	/*
	 * @PostMapping("/cartitems/checkout/{buyerID}") public String
	 * chekOoutByBuyerId(@PathVariable (value="buyerID") Integer
	 * buyerId, @RequestBody Transactions transaction) { return
	 * purchaseService.checkOut(transaction, buyerId);
	 * 
	 * }
	 */
	   
	   @PutMapping("/cartitem/{buyerId}")
	   public CartItems updateCartQuantity(@RequestBody CartItems cartItem) {
		   System.out.println("hi"+cartItem);
		   return cartItemService.incDecItem(cartItem);
	   }
	
	   
	// Delete cartitem 

	   @DeleteMapping("/deletecartitem/{carItemId}") 
	   public void deleteCartItemByBuyerId(@PathVariable("carItemId") Integer carItemId) {
	   cartItemService.deleteCartItem(carItemId); 
	   }
	
	   @PostMapping("/checkout/{bids}")
		public String checkOut(@RequestBody Transactions transac,@PathVariable("bids") int buid)
		{
			return cartItemService.checkOut(transac,buid);
		}
	
	   @DeleteMapping("/emptyCart/{bid}")
		public void emptyCart(@PathVariable ("bid") int buyid)
		{
			System.out.println("in empty cart");
			cartItemService.emptyCart(buyid);
			
			//return "\"Cart emptied\"";
		}
	
	}

