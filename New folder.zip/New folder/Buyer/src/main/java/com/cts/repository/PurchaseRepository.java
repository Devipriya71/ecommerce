package com.cts.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

import com.cts.model.PurchaseHistory;
import com.cts.model.Transactions;

public interface PurchaseRepository extends JpaRepositoryImplementation<PurchaseHistory, Integer>{

}
