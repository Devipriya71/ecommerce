package com.voila.demo.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

import com.voila.demo.model.PurchaseHistory;
import com.voila.demo.model.Transactions;

public interface PurchaseRepository extends JpaRepositoryImplementation<PurchaseHistory, Integer>{

}
