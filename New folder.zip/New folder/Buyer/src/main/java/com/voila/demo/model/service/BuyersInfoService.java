package com.voila.demo.model.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.voila.demo.model.BuyerInfo;
import com.voila.demo.repository.BuyerRepository;

@Service
public class BuyersInfoService implements UserDetailsService {
	
	@Autowired
	private BuyerRepository buyerRepository;
	
	// added 10 march 
	
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		BuyerInfo buyer = buyerRepository.findByname(username);
		if(buyer == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(buyer.getName(), buyer.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}
	
	// end of added 10 march
	
	public List<BuyerInfo> getAllBuyers(){
		List<BuyerInfo> buyersRecord = new ArrayList<BuyerInfo>();
		buyerRepository.findAll().forEach(buyersRecord::add);    
		return buyersRecord;
	}
	
	// add new buyer details
	public BuyerInfo addBuyer(BuyerInfo buyer) {
		BuyerInfo newBuyer = new BuyerInfo();
		newBuyer.setName(buyer.getName());
		newBuyer.setEmailId(buyer.getEmailId());
		newBuyer.setMobileNo(buyer.getMobileNo());
		newBuyer.setDate(buyer.getDate());
		newBuyer.setPassword(bcryptEncoder.encode(buyer.getPassword()));
		return buyerRepository.save(newBuyer);
		
	}
	
	/*
	 * public BuyerInfo getBuyerById(BuyerInfo buyer) { return
	 * buyerRepository.findAll(id); }
	 */
	// getById method
	public Optional<BuyerInfo> getBuyer(@PathVariable Integer buyerId) {
		return buyerRepository.findById(buyerId);
				/*.orElseThrow(()-> new BuyerInfoNotFoundException(id));*/
	}
	
	// Delete Buyer BL
	public void deleteBuyersInfo(Integer buyerId) {
		// TODO Auto-generated method stub
		buyerRepository.deleteById(buyerId);
	}
	
	// Update BuyersInfo BL
	public BuyerInfo saveOrUpdate(BuyerInfo buyerInfo, Integer id, String emailId, Date date ) {
		// TODO Auto-generated method stub
		/* buyerRepository.save(buyerInfo); */
		Optional<BuyerInfo> buyer = buyerRepository.findById(id);
		buyerInfo.setEmailId(emailId);
		buyerInfo.setDate(date);
		return buyerRepository.save(buyerInfo);
		
		
		// here onward we have to complete
		
	}

	public BuyerInfo findOne(String username) {
		// TODO Auto-generated method stub
		return buyerRepository.findByname(username);
	}
	
}
