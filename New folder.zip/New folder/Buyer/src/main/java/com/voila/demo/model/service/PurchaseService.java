package com.voila.demo.model.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.voila.demo.model.BuyerInfo;
import com.voila.demo.model.CartItems;
import com.voila.demo.model.PurchaseHistory;
import com.voila.demo.model.Transactions;
import com.voila.demo.repository.BuyerRepository;
import com.voila.demo.repository.CartItemRepository;
import com.voila.demo.repository.PurchaseRepository;
import com.voila.demo.repository.Transactionrepository;

@Service
public class PurchaseService {
	
	@Autowired
	private CartItemRepository cartItemRepository;
	
	@Autowired
	private BuyerRepository buyerRepository;
	
	@Autowired
	private Transactionrepository transactionRepository;
	
	@Autowired
	private PurchaseRepository purchaseRepository;
	
	public String checkOut(Transactions transaction, Integer buyerId) {
		
		Double totalAmount = 0.00;
		List<CartItems> cartItems = cartItemRepository.getCartItemByBuyerId(buyerId);
		for(CartItems items : cartItems) {
			Optional<CartItems> item = cartItemRepository.findById(items.getCartItemId());
//			totalAmount += item.get().getPrice();
		}
		
		BuyerInfo buyer = buyerRepository.getOne(buyerId);
		transaction.setBuyer(buyer);
		List<CartItems> cartitems=cartItemRepository.getCartItemByBuyerId(buyerId);
		for(int i=0;i<cartitems.size();i++) {
			totalAmount=totalAmount+cartItems.get(i).getPrice();
		}
		transactionRepository.save(transaction);
		for(int i=0;i<cartitems.size();i++) {
			CartItems items = cartitems.get(i);
			PurchaseHistory purchaseHis = new PurchaseHistory();
			purchaseHis.setBuyer(buyer);
			purchaseHis.setTransactionId(transaction);
			int quantity = items.getQuantity();
			purchaseHis.setItemQuantity(quantity);
			purchaseHis.setItemId(items.getItemId());
			Date date = transaction.getDate();
			purchaseHis.setDate(date);
			purchaseHis.setRemarks("good");
			purchaseRepository.save(purchaseHis);
			cartItemRepository.delete(items);
			//System.out.println(purchaseHis.getRemarks());
			System.out.println(totalAmount);
		}
		return "Success!";
		
	}

}
