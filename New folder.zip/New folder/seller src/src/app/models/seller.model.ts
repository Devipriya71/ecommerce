export class SellerModel {
    name: string;
    password:string;
    companyName:string;
    companyDescription:string;
    gstin:string;
    postalAddress: PostalAddressModel = new PostalAddressModel();
    website:string;
    emailId:string;
    mobileNo:number;
}

export class PostalAddressModel {
    houseNumber: number;
    streetName: string;
    locality: string;
    city: string;
    state: string;
    pinCode: number;
}