import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SellerRegistrationComponent } from './seller-registration/seller-registration.component';
import { AddproductComponent } from './addproduct/addproduct.component';


const routes: Routes = [
  { path: 'sellerreg', component: SellerRegistrationComponent },
  { path: 'addproduct', component: AddproductComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
