import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { BuyerSignupComponent } from './buyer-signup/buyer-signup.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { CartComponent } from './cart/cart.component';
import { BuyerLoginComponent } from './buyer-login/buyer-login.component';
import { ShowproductsComponent } from './showproducts/showproducts.component';

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    BuyerSignupComponent,
    HomeComponent,
    CartComponent,
    BuyerLoginComponent,
    ShowproductsComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
