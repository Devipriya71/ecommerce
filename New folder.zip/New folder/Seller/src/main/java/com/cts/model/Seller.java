package com.cts.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;



@Entity
 
public class Seller {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "seller_id") 
	private Integer id;
	
	@Column(name = "username")
	private String name;
	
	@Column(name = "password")
	private String password;
	
	@Column(name = "company_name")
	private String companyName;
	
	@Column(name="gstin")
	private String gstin;
	
	@Column(name = "company_description")
	private String companyDescription;
	
	@OneToOne
	@JoinColumn(name = "postal_ddress")
	private Address postalAddress;
	
	@Column(name = "website")
	private String website;
	
	@Column(name = "email_id")
	private String emailId;
	
	@Column(name = "mobile_number")
	/* @Size(min=0,max=10) */
	private String mobileNo;
	
	/*
	 * @Temporal(TemporalType.TIMESTAMP)
	 * 
	 * @Column(name = "created_at", nullable = false, updatable = false)
	 * 
	 * @CreatedDate private Date createdAt;
	 */
	/*
	 * @Temporal(value=TemporalType.TIMESTAMP)
	 * 
	 * @Column(name = "date") private Date date;
	 */
	
	

	public Seller(String name, String password, String companyName, String companyDescription, String gstin,
			Address postalAddress, String website, String emailId, String mobileNo) {
		super();
		this.name = name;
		this.password = password;
		this.companyName = companyName;
		this.companyDescription = companyDescription;
		this.gstin=gstin;
		this.postalAddress = postalAddress;
		this.website = website;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
	}
	
	public Seller() {
		super();
	}

	public Integer getId() {
		return id;
	}

	
	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyDescription() {
		return companyDescription;
	}

	public void setCompanyDescription(String companyDescription) {
		this.companyDescription = companyDescription;
	}
	
	

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public Address getPostalAddress() {
		return postalAddress;
	}

	public void setPostalAddress(Address postalAddress) {
		this.postalAddress = postalAddress;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	@Override
	public String toString() {
		return "Seller [id=" + id + ", name=" + name + ", password=" + password + ", companyName=" + companyName
				+ ", gstin=" + gstin + ", companyDescription=" + companyDescription + ", postalAddress=" + postalAddress
				+ ", website=" + website + ", emailId=" + emailId + ", mobileNo=" + mobileNo + "]";
	}

	

	
	
	

}
