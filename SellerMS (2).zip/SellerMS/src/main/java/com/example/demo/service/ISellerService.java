package com.example.demo.service;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Seller;



@Service
public interface ISellerService {

	public String createSeller(Seller sdetails);
    public String updateSeller(Integer sellerid, Seller sdetails);

}
