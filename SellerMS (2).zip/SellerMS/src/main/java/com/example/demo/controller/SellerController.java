package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Seller;
import com.example.demo.service.ISellerService;
import com.example.demo.service.SellerService;




@RestController
@RequestMapping("/seller")
public class SellerController {
	
	@Autowired
	public SellerService sellerservice;
	
	
	@PostMapping("/addseller")
	public String addSeller(@RequestBody Seller seller)
	{
		return sellerservice.addSeller(seller);
	}
	/*
	 * @PostMapping("/updateSeller/{sid}") public String
	 * updateSeller(@PathVariable("sid") Integer sellerid,@RequestBody Seller
	 * sdetails) { return iserv.updateSeller(sellerid,sdetails); }
	 */
}
