package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.SellerDao;
import com.example.demo.entity.Seller;

@Service
public class SellerService 
{
	@Autowired
	public SellerDao sdao;

	public String addSeller(Seller seller)
	{
		sdao.save(seller);
		return "\"Seller was added\"";
	}
	/*
	 * @Override public String updateSeller(Integer sellerid, SellerDetails
	 * sdetails) { SellerDetails sdet=seldao.getOne(sellerid); String
	 * usname=sdetails.getUsername(); String pass=sdetails.getPassword(); String
	 * compname=sdetails.getCompanyname(); float gstin=sdetails.getGstin(); String
	 * compdescription=sdetails.getCompanydescription(); String
	 * postaddres=sdetails.getPostal_address(); String site=sdetails.getWebsite();
	 * String emailid=sdetails.getEmailid(); long
	 * contactnumber=sdetails.getContact_number(); sdet.setUsername(usname);
	 * sdet.setPassword(pass); sdet.setCompanyname(compname); sdet.setGstin(gstin);
	 * sdet.setCompanydescription(compdescription);
	 * sdet.setPostal_address(postaddres); sdet.setWebsite(site);
	 * sdet.setEmailid(emailid); sdet.setContact_number(contactnumber); return
	 * "\"Seller Details Updated\""; }
	 */

}
