package com.cts;
 import java.sql.ResultSet;
	import java.sql.SQLException;

	import javax.sql.DataSource;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.jdbc.core.JdbcTemplate;
	import org.springframework.jdbc.core.RowMapper;
	import org.springframework.stereotype.Repository;

	@Repository
	public class Productdao {
		@Autowired
		private DataSource ds;
		private JdbcTemplate jdbc;
		
		//SETTER FOR JDBC TEMPLATE
		
		public void setJdbc(JdbcTemplate jdbc) {
			
			this.jdbc = jdbc;
		}
		
		//ADDING PRODUCT
		
		public int addProduct(Product product) {
			
			jdbc = new JdbcTemplate(ds);
			int storedStatus = jdbc.update("INSERT INTO product VALUES(?,?,?,?)", new Object[] {product.getId(),product.getName(),product.getQuantity(),product.getPrice()});
			System.out.println(storedStatus);
			return product.getId();
			
		}
		
		public int deleteProduct(int productId) {
			jdbc=new JdbcTemplate(ds);
			int deletedStatus=jdbc.update("DELETE from product WHERE pid = ?",new Object[]{productId});
			System.out.println(deletedStatus);
			return deletedStatus;
		}
		
		public int updateProduct(Product product) {
			jdbc=new JdbcTemplate(ds);
			int updateStatus=jdbc.update("UPDATE product SET pname = ? , pquantity = ? , pprice = ? where pid = ?",new Object[]{product. getId(),product. getName(),product.getQuantity(),product.getPrice()});
		//	System.out.println(updateStatus);
			return updateStatus;
		}
		
		//GETBYID
		public Product getById(int id) {
			jdbc = new JdbcTemplate(ds);
			String sql = "SELECT * FROM product WHERE pid=?";
			Product product = (Product)jdbc.queryForObject(sql, new Object[] {id},

					new RowMapper<Product>() {
				public Product mapRow(ResultSet rs, int rowNum) throws SQLException {

					Product product = new Product();

					product.setId(rs.getInt(1));
					product.setName(rs.getString(2));
					product.setQuantity(rs.getInt(3));
					product.setPrice(rs.getFloat(4));

					return product;
				}

			});
			return product;
		}
		
		
		
		
		
		

		
	}


