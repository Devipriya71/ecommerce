package com.cts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Productservice {
		
		@Autowired
		Productdao pDao;
		
		//ADDING PRODUCT
		
		public int addProduct(Product product) {
			
			return pDao.addProduct(product);
		}
		
	public Product getById(int Id) {
			
			return pDao.getById(Id);
		}

	public int updateProduct(Product product)
	{
		return pDao.updateProduct(product);
	}
	
	public int deleteProduct(int Id)
	{
		return pDao.deleteProduct(Id);
	}
		

	}



