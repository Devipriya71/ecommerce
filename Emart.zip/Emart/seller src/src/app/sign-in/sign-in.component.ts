import { Component, OnInit } from '@angular/core';
import { SellerModel } from '../models/seller.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {

  

  ngOnInit(): void {
  }

  username:string;
  password:string;
   seller:SellerModel=new SellerModel();
  constructor( private router: Router) { }

  onSubmit() {
    console.log(this.seller.name);
    console.log(this.seller.password);
   
      if(this.seller.name=="seller" && this.seller.password=="seller123")
      {
        this.router.navigate(['Home']);
        alert("login successful");
      }
      else
      {
        alert("Enter the correct username and password");
      }
    }


}
