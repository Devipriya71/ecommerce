import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SellerRegistrationComponent } from './seller-registration/seller-registration.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { LogoutComponent } from './logout/logout.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { HomeComponent } from './home/home.component';


const routes: Routes = [
  { path: 'sellerreg', component: SellerRegistrationComponent },
  { path: 'addproduct', component: AddproductComponent },
  { path: 'logout', component: LogoutComponent},
  { path: 'sellerlogin', component: SignInComponent},
  { path: 'home', component: HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
