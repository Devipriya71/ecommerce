import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BuyerModel } from '../models/buyer.model';
import { Observable } from 'rxjs';
import { BuyerLoginComponent } from '../buyer-login/buyer-login.component';
import { ApiResponse } from '../models/buyer.model';

@Injectable({
  providedIn: 'root'
})
export class BuyerLoginService {

  constructor(private http:HttpClient) { }

  private baseUrl = "http://localhost:8081/";

  public buyerLogin(buyer: BuyerModel):Observable<any> {
    return this.http.get<BuyerLoginComponent>(this.baseUrl+'/buyersinfo/3');
  }
  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8081/' + 'token/generate-token', loginPayload);
}
}
