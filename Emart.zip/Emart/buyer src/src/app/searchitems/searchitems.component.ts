import { Component, OnInit } from '@angular/core';
import { ProductService} from '../service/product.service';
import { ProductsModel } from '../models/products.model';

@Component({
  selector: 'app-searchitems',
  templateUrl: './searchitems.component.html',
  styleUrls: ['./searchitems.component.css']
})
export class SearchitemsComponent implements OnInit {
  productName:String;
  Product: ProductsModel[];
  title = 'Buyer';

  constructor(private dataService: ProductService) { }

  ngOnInit() {
  }

  private searchProducts() {
    this.dataService.getItemsByName(this.productName)
    .subscribe(ProductsModel => this.Product = ProductsModel);
  }

  onSubmit() {
    this.searchProducts();
  }
}








