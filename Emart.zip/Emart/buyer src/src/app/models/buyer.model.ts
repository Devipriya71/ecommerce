export class BuyerModel {
    id:number;
    name: string;
    emailId: string;
    password: string;
    mobileNo: number;
}

export class ApiResponse {

    status: number;
    message: number;
    result: any;
  }
  