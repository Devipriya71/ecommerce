package com.cts.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cts.model.BuyerInfo;
import com.cts.model.CartItems;

public interface CartItemRepository extends JpaRepository<CartItems, Integer>{
	@Query(value = "select * from cart_items where buyer_id=?1", nativeQuery = true )
	public List<CartItems> getCartItemByBuyerId(Integer buyerId);
	
	@Transactional
	 @Modifying
	 @Query(value = "SELECT * FROM cart_items WHERE cart_items.buyer_id = :buid",nativeQuery = true)
	public List<CartItems> byid(@Param("buid") int buid);
	
	@Transactional
	  @Modifying
	  @Query(value = "DELETE FROM cart_items WHERE  cart_items.buyer_id = :buyid",nativeQuery = true) 
	  public void emptyCart(@Param("buyid")int buyid);

}
