package com.cts.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

import com.cts.model.Transactions;

public interface Transactionrepository extends JpaRepositoryImplementation<Transactions, Integer>{

}
