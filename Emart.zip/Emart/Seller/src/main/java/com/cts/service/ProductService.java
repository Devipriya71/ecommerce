package com.cts.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Product;
import com.cts.model.Seller;
import com.cts.repository.ProductRepository;
import com.cts.repository.SellerRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private SellerRepository sellerRepository;
	


	public List<Product> getAllProducts() { 
		List<Product> allProducts = new ArrayList<Product>();
		productRepository.findAll().forEach(allProducts::add);
		return allProducts;
	}


	// add new product details
	public Product addProduct(Product newProduct, Integer sellerId) {
		System.out.println("hi");
		Optional<Seller> seller = sellerRepository.findById(sellerId);
		newProduct.setSeller(seller.get());
		return productRepository.save(newProduct);

	}


	public List<Product> getSearchProduct(Product newProduct) {

		return productRepository.findProduct(newProduct.getProductName()); }

	
	
	public List<Product> searchProduct(String productname) {
		return productRepository.searchproduct(productname);
	}



}
