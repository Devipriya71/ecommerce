package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.model.Product;
@Repository
public interface ProductRepository extends JpaRepository<Product, Integer>{
	
	
	
	 @Query(value= "from Product where lower(productName) LIKE %:productName%") 
	 public List<Product> findProduct(@Param("productName") String product);
	 
	 @Query(value="SELECT * FROM product WHERE product.productname LIKE :productname%"
			 ,nativeQuery = true)
			 List<Product> searchproduct(@Param("productname")String productname);

	 
}
