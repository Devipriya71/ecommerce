package com.cts.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Cart;
import com.cts.Purchasehistory;
import com.cts.Transactions;
import com.cts.repository.BuyerRepository;
import com.cts.repository.CartRepository;

@Service
public class Cartservice {
	
	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
	private BuyerRepository buyerRepository;
	

}
