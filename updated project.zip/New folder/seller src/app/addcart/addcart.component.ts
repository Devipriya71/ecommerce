import { Component, OnInit, Input } from '@angular/core';
import { Product } from '../Items';
import { BuyerServiceService } from '../buyer-service.service';
import { Cart } from '../Shoppingcart';


@Component({
  selector: 'app-addcart',
  templateUrl: './addcart.component.html',
  styleUrls: ['./addcart.component.css']
})
export class AddcartComponent implements OnInit {

  constructor(private cartService:BuyerServiceService) { }

 @Input()
  at:Product =new Product();
  cart:Cart =new Cart();

  ngOnInit(): void {
    this.cart=new Cart();
  }
  addCart()
  {
    this.cartService.addCart(this.cart).subscribe(cart => this.cart=cart);
  }
  onSubmit(){
    this.cart.productid=this.at.productid;
    this.cart.quantity=this.at.quantity;
    this.cart.total_price=this.at.price;
    this.cart.productname=this.at.productname;
  console.log("Items added");
 this.addCart();
  }
}
