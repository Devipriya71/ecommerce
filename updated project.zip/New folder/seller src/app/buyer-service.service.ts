import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Cart, ShopCart } from './Shoppingcart';
import { User } from './Buyer';

@Injectable({
  providedIn: 'root'
})
export class BuyerServiceService {
  

  private baseUrl="http://localhost:8082/product";
  private baseUrl1="http://localhost:8081/cart/addItem/1";
  private baseUrl2="http://localhost:8081/buyer";
  constructor(private http:HttpClient ) { }
  getItemsByName(productName: String) :Observable<any> {
    return this.http.get(`${this.baseUrl}`+`/getMatchItems`+`/${productName}`);
  }

  addCart(cart:object):Observable<any> {
    console.log("ejfhw");
    console.log(cart);
   return  this.http.post(`${this.baseUrl1}`,cart);
  }

  createbuyer(buyer: User) :Observable<any>{
    return this.http.post(`${this.baseUrl2}`+`/addUser`,buyer);
   } 
  
  displayCartItems() : Observable<any>{

    return this.http.get(`http://localhost:8081/cart/getItems`);
 
  }
  deleteCartItem() :Observable<any>{
    return this.http.delete(`http://localhost:8081/cart/deleteItem/4`);
  }
  
  emptyCart() :Observable<any>{
    return this.http.delete(`http://localhost:8081/cart/emptyCart/1`);
  }


  updateCartItems(incart: ShopCart) :Observable<any>{
    console.log("jfshjsg");
    console.log(incart);
   return this.http.post(`http://localhost:8081/cart/updatecart/1`,incart);
  }

  checkOutCart(checkout:ShopCart) :Observable<any>
  {
    return this.http.post(`http://localhost:8081/cart/checkout/1`,checkout);
 
  }
}