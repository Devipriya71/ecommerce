import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {SearchitemsComponent} from './searchitems/searchitems.component';
import {DisplaycartComponent} from './displaycart/displaycart.component';
import {BuyersignupComponent} from './buyersignup/buyersignup.component';
import { BuyerloginComponent } from './buyerlogin/buyerlogin.component';
import { HomeComponent } from './home/home.component';
import { BuyerlogoutComponent } from './buyerlogout/buyerlogout.component';
const routes: Routes = [ 
  {path : 'buyersignup',component:BuyersignupComponent},
  {path : 'searchitems',component:SearchitemsComponent},
  {path : 'Home/displaycart' , component:DisplaycartComponent},
  {path: 'buyer-signup', component: BuyersignupComponent},
  { path: 'buyerlogin', component: BuyerloginComponent},
  { path: 'Home', component: HomeComponent},
  { path: 'buyerlogout', component: BuyerlogoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
