package com.example.demo.services;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Category;
import com.example.demo.Entity.SubCategory;
import com.example.demo.repositry.CategoryDao;
import com.example.demo.repositry.SubCategoryDao;

@Service
public class SubCategoryService implements ISubCategoryService{
@Autowired
private SubCategoryDao subdao;
@Autowired
private CategoryDao cdao;


	@Override
	public List<SubCategory> getAllSubCategories() {
		
		return subdao.findAll();
	}

	@Override
	public String addAllSubCategories(int category_id,SubCategory cat)
	{
	Category ct=cdao.getOne(category_id);
	cat.setCat(ct);
	System.out.println("subcategory");
	subdao.save(cat);
	
	return "\"subcategories\"";
	}

}
