package com.example.demo.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.Entity.SubCategory;


@Service
public interface ISubCategoryService {

	List<SubCategory> getAllSubCategories();
	
	String addAllSubCategories(int category_id,SubCategory sub);

}
