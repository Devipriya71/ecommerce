package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.SellerDetails;
import com.example.demo.services.ISellerService;

@RestController
@RequestMapping("/seller")
public class SellerController {
	
	@Autowired(required=true)
	public ISellerService isellerserv;
	
	@PostMapping("/addSeller")
	public String createSeller(@RequestBody SellerDetails sdetails)
	{
		return isellerserv.addSeller(sdetails);
	}
	
    @PostMapping("/updateSeller/{sid}")
    public String updateSeller(@PathVariable("sid") Integer sellerid,@RequestBody SellerDetails sdetails)
    {
    	return isellerserv.updateSeller(sellerid,sdetails);
    }
}
