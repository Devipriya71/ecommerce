package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Category;
import com.example.demo.repositry.CategoryDao;

@Service
public class CategoryService implements ICategoryService {
@Autowired
private CategoryDao catdao;

	@Override
	public List<Category> getAllCatogeris() {
		
		return catdao.findAll();
	}
	
	@Override
	public String addCategory(Category cat)
	{
	 catdao.save(cat);
	 return "\"Category Added\"";
	}

}
