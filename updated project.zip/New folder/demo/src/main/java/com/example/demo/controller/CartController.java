package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.ShoppingCart;
import com.example.demo.entity.Transactions;
import com.example.demo.service.BuyerService;
import com.example.demo.service.CartService;


@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/cart")
public class CartController {
	@Autowired
	public BuyerService bserv;
	@Autowired
	public CartService cserv;
	

	@PostMapping("/addItem/{id}")
	public String addCartItem( @PathVariable ("id") int buyerid,@RequestBody ShoppingCart cart)
	{
		return cserv.addCartItem(buyerid,cart);
	}
	
	
	@GetMapping("/getItems")
	public List<ShoppingCart> getCart()
	{
		System.out.println("add");
		return cserv.getCart();
	}
	
	@DeleteMapping("/deleteItem/{id}")
	public String deleteCartItem(@PathVariable ("id") int cart_id)
	{
		cserv.deleteCartItem(cart_id);
		return "\" Item Deleted from te cart\"";
	}
	
	@DeleteMapping("/emptyCart/{bid}")
	public void emptyCart(@PathVariable ("bid") int buyid)
	{
		System.out.println("in empty cart");
		cserv.emptyCart(buyid);
		
		//return "\"Cart emptied\"";
	}
	
	@PostMapping("/updatecart/{bid}")
	public String updateCart(@RequestBody ShoppingCart scart1,@PathVariable("bid")int buid)
	{
		return cserv.updateCart(scart1,buid);
	}
	
	@PostMapping("/checkout/{bids}")
	public String checkOut(@RequestBody Transactions transac,@PathVariable("bids") int buid)
	{
		return cserv.checkOut(transac,buid);
	}
	
	
}