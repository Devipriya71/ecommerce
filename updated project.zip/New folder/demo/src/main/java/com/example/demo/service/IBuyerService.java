package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Buyer;
import com.example.demo.entity.Product;

public interface IBuyerService {

	public List<Product> getAllProducts();
	
	public String addProduct(Buyer buyer);
	
	public List<Buyer> getUsers();
	
	public String findByIdAndPostId(int buyerid);
}
