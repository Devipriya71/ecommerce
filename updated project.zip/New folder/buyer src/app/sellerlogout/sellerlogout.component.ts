import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sellerlogout',
  templateUrl: './sellerlogout.component.html',
  styleUrls: ['./sellerlogout.component.css']
})
export class SellerlogoutComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
    this.router.navigate(['sellerlogin']);
    alert("you will be logged out");
  }

}
