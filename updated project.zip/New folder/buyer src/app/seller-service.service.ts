import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Seller } from './Seller';
import { Product } from './Items';


@Injectable({
  providedIn: 'root'
})
export class SellerServiceService {
  
  private baseUrl="http://localhost:8082/product";
  private baseUrl2="http://localhost:8082/seller";
  constructor(private http : HttpClient) {}
  addItems(product: Product)  :Observable<any>{
    return this.http.post(`${this.baseUrl}/addProduct/1/1`,product);
   }
   deleteItems(productid: number) :Observable<any>{
     return this.http.delete(`${this.baseUrl}/DeleteItem/${productid}/2`,{responseType:'text'});
   }
   updateItems(productid: number):Observable<any>{
    return this.http.post(`${this.baseUrl}/updateProduct/2/2`,{responseType:'text'});
   }
   createseller(seller: Seller) :Observable<any>{
    return this.http.post(`${this.baseUrl2}`+`/addUser`,seller);
   } 
  
   
}
