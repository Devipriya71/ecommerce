import { Component, OnInit } from '@angular/core';
import { Product } from '../Items';
import { SellerServiceService } from '../seller-service.service';

@Component({
  selector: 'app-updatestock',
  templateUrl: './updatestock.component.html',
  styleUrls: ['./updatestock.component.css']
})
export class UpdatestockComponent implements OnInit {
  product:Product=new Product();
  productid:number;
  constructor(private up:SellerServiceService) { }

  ngOnInit(): void {
  }
  onSubmit()
  {
  this.up.updateItems(this.productid).subscribe(productid => this.productid=productid);
  alert("Items updated");
  }
}
