package com.egg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.egg.model.BuyerInfo;

public interface BuyerRepository extends JpaRepository<BuyerInfo, Integer>{
	
	public BuyerInfo findByName(String name);

}
