package com.egg.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

/**
 * Date :Feb 18,2020
 * @author Vivek
 * @version 1.0
 *
 */

@Entity
 
public class BuyerInfo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "buyer_id") 
	private Integer id;
	
	@Column(name = "username")
	private String name;
	
	@Column(name = "password")
	private String password;
	
	@Column(name = "email_id")
	private String emailId;
	
	@Column(name = "mobile_number")
	/* @Size(min=0,max=10) */
	private String mobileNo;
	
	/*
	 * @Temporal(TemporalType.TIMESTAMP)
	 * 
	 * @Column(name = "created_at", nullable = false, updatable = false)
	 * 
	 * @CreatedDate private Date createdAt;
	 */
	@Temporal(value=TemporalType.TIMESTAMP)
	@Column(name = "date")
	private Date date;

	public BuyerInfo(String name, String password, String emailId, String mobileNo, Date date) {
		super();
		this.name = name;
		this.password = password;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.date = date;
	}

	public BuyerInfo() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "BuyerInfo [id=" + id + ", name=" + name + ", password=" + password + ", emailId=" + emailId
				+ ", mobileNo=" + mobileNo + ", date=" + date + "]";
	}
	
	

}
