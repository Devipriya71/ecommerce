package com.egg.service;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.egg.dao.BuyerRepository;
import com.egg.model.BuyerInfo;


@Service
public class BuyersInfoService implements UserDetailsService{
	
	@Autowired
	private BuyerRepository buyerRepository;
	
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;
	
	public BuyerInfo addbuyer(BuyerInfo buyer) {
		 buyer.setPassword(bcryptEncoder.encode(buyer.getPassword()));
		 System.out.println("hiiii");
		 return buyerRepository.save(buyer);
		 
	}
	
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		BuyerInfo buyer  = buyerRepository.findByName(username);
		if(buyer == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(buyer.getName(), buyer.getPassword(), getAuthority());
	}


	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_Buyer"));
	}


	public BuyerInfo findOne(String username) {
		return buyerRepository.findByName(username);
	}
	
	
	
	public List<BuyerInfo> getAllBuyers(){
		List<BuyerInfo> buyersRecord = new ArrayList<BuyerInfo>();
		buyerRepository.findAll().forEach(buyersRecord::add);    
		return buyersRecord;
	}
	
	/*
	 * public BuyerInfo getBuyerById(BuyerInfo buyer) { return
	 * buyerRepository.findAll(id); }
	 */
	// getById method
	public Optional<BuyerInfo> getBuyer(@PathVariable Integer buyerId) {
		return buyerRepository.findById(buyerId);
				/*.orElseThrow(()-> new BuyerInfoNotFoundException(id));*/
	}
	
	// Delete Buyer BL
	public void deleteBuyersInfo(Integer buyerId) {
		// TODO Auto-generated method stub
		buyerRepository.deleteById(buyerId);
	}
	
	// Update BuyersInfo BL
	public BuyerInfo saveOrUpdate(BuyerInfo buyerInfo, Integer id, String emailId, Date date ) {
		// TODO Auto-generated method stub
		/* buyerRepository.save(buyerInfo); */
		Optional<BuyerInfo> buyer = buyerRepository.findById(id);
		buyerInfo.setEmailId(emailId);
		buyerInfo.setDate(date);
		return buyerRepository.save(buyerInfo);
		
		
		// here onward we have to complete
		
	}
	
}
