import { Component } from '@angular/core';

@Component({
    selector: 'app-contact', //you can use any selector of your choice
    template: `<h2>Contact</h2>`
  })
  export class ContactComponent { }