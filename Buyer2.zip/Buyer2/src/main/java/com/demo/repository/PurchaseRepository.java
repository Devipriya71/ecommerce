package com.demo.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

import com.demo.entity.PurchaseHistory;

public interface PurchaseRepository extends JpaRepositoryImplementation<PurchaseHistory, Integer>{

}
