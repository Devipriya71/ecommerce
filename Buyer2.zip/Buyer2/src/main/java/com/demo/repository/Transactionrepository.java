package com.demo.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

import com.demo.entity.Transactions;

public interface Transactionrepository extends JpaRepositoryImplementation<Transactions, Integer>{

}
