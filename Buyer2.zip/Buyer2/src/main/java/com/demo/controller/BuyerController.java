package com.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.BuyerInfo;
import com.demo.service.BuyersInfoService;

@RestController
public class BuyerController {
	
	/* private final BuyerRepository repository; */
	@Autowired
	private BuyersInfoService buyerservice;
	
	
	@RequestMapping("/getallbuyers")    
	public List<BuyerInfo> getAllUser()  
	{    
	return buyerservice.getAllBuyers();    
	} 
	
	// post method to insert new buyer details
	@PostMapping("/addbuyer")
	public BuyerInfo newBuyerInfo(@RequestBody BuyerInfo newBuyerInfo) {
		BuyerInfo buyerInfo = buyerservice.addBuyer(newBuyerInfo);
		return buyerInfo;
	}
	
	// getById method
	@GetMapping("/buyer/{id}")
	public BuyerInfo getBuyerInfo(@PathVariable(value="id") Integer buyerId) {
		Optional<BuyerInfo> showBuyer = buyerservice.getBuyer(buyerId);
		return showBuyer.get();
	}
	
	// Delete Buyer
	@DeleteMapping("/buyer/{buyerId}")
	private void deleteBuyerInfo(@PathVariable("buyerId") Integer buyerId) {
		buyerservice.deleteBuyersInfo(buyerId);
	}
	
                                                     
	
	 @PostMapping("/updatebuyer/{buyerId}")
	    public String updateBuyerInfo(@PathVariable("buyerId") Integer buyerId,@RequestBody BuyerInfo buyersinfo)
	    {
	    	return buyerservice.updateBuyerInfo(buyerId,buyersinfo);
	    }
	 
	@GetMapping("")
	
	
	@RequestMapping("/buyer")
	public String sayHi() {
		return "Hi Buyer";
	}
}
