package com.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entity.BuyerInfo;
import com.demo.entity.CartItems;
import com.demo.repository.BuyerRepository;
import com.demo.repository.CartItemRepository;

@Service
public class CartItemService {
	
	@Autowired
	private CartItemRepository cartItemRepository;
	
	@Autowired
	private BuyerRepository buyerRepository;
	/*
	 * @Autowired private BuyerRepository buyerRepository;
	 */

	public List<CartItems> getAllCartItems() {
		// TODO Auto-generated method stub
		List<CartItems> allCartItems = new ArrayList<CartItems>();
		cartItemRepository.findAll().forEach(allCartItems::add);
		/* cartItemRepository.findAll().forEach(allCartItems::add); */
		return allCartItems;
	}

	public CartItems addCartItem(CartItems newCartItems, Integer buyerId) {
		// TODO Auto-generated method stub
		System.out.println("In service");
		Optional<BuyerInfo> buyer = buyerRepository.findById(buyerId);
		newCartItems.setBuyer(buyer.get());
		return cartItemRepository.save(newCartItems);
		
	}
	
	public List<CartItems> getCartItems( Integer buyerId) {
		// TODO Auto-generated method stub
		
		return cartItemRepository.getCartItemByBuyerId(buyerId);
	}
	
	
	
	
}
