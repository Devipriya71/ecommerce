package com.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.demo.entity.BuyerInfo;
import com.demo.repository.BuyerRepository;

@Service
public class BuyersInfoService {

	@Autowired
	private BuyerRepository buyerRepository;

	public List<BuyerInfo> getAllBuyers() {
		List<BuyerInfo> buyerslist = new ArrayList<BuyerInfo>();
		buyerRepository.findAll().forEach(buyerslist::add);
		return buyerslist;
	}

	// add new buyer 
	public BuyerInfo addBuyer(BuyerInfo buyer) {
		return buyerRepository.save(buyer);

	}

	
	// get buyer details through getById method
	public Optional<BuyerInfo> getBuyer(@PathVariable Integer buyerId) {
		return buyerRepository.findById(buyerId);
		/* .orElseThrow(()-> new BuyerInfoNotFoundException(id)); */
	}

	// Delete Buyer using id
	public void deleteBuyersInfo(Integer buyerId) {
		// TODO Auto-generated method stub
		buyerRepository.deleteById(buyerId);
	}

	
	public String updateBuyerInfo(Integer buyerId, BuyerInfo buyersinfo) {

		BuyerInfo sdet = buyerRepository.getOne(buyerId);
		String usname = buyersinfo.getName();
		String pass = buyersinfo.getPassword();

		String emailid = buyersinfo.getEmailId();
		String MobileNo = buyersinfo.getMobileNo();
		sdet.setName(usname);
		sdet.setPassword(pass);
		sdet.setMobileNo(MobileNo);

		sdet.setEmailId(emailid);

		System.out.println(sdet);
		buyerRepository.save(sdet);
		return "\"Buyer details are Updated\"";
	}
}
