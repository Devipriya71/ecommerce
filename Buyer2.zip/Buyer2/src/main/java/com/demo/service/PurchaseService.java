package com.demo.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entity.BuyerInfo;
import com.demo.entity.CartItems;
import com.demo.entity.PurchaseHistory;
import com.demo.entity.Transactions;
import com.demo.repository.BuyerRepository;
import com.demo.repository.CartItemRepository;
import com.demo.repository.PurchaseRepository;
import com.demo.repository.Transactionrepository;

@Service
public class PurchaseService {
	
	@Autowired
	private CartItemRepository cartItemRepository;
	
	@Autowired
	private BuyerRepository buyerRepository;
	
	@Autowired
	private Transactionrepository transactionRepository;
	
	@Autowired
	private PurchaseRepository purchaseRepository;
	
	public String checkOut(Transactions transaction, Integer buyerId) {
		
		Double totalAmount = 0.00;
		List<CartItems> cartItems = cartItemRepository.getCartItemByBuyerId(buyerId);
		for(CartItems items : cartItems) {
			Optional<CartItems> item = cartItemRepository.findById(items.getCartItemId());
			totalAmount += item.get().getPrice();
		}
		
		BuyerInfo buyer = buyerRepository.getOne(buyerId);
		transaction.setBuyer(buyer);
		List<CartItems> cartitems=cartItemRepository.getCartItemByBuyerId(buyerId);
		transactionRepository.save(transaction);
		for(int i=0;i<cartitems.size();i++) {
			CartItems items = cartitems.get(i);
			PurchaseHistory purchaseHistory = new PurchaseHistory();
			purchaseHistory.setBuyer(buyer);
			purchaseHistory.setTransactionId(transaction);
			int quantity = items.getQuantity();
			purchaseHistory.setItemQuantity(quantity);
			purchaseHistory.setItemId(items.getItemId());
			Date date = transaction.getDate();
			purchaseHistory.setDate(date);
			purchaseHistory.setRemarks("good");
			purchaseRepository.save(purchaseHistory);
			cartItemRepository.delete(items);
			//System.out.println(purchaseHis.getRemarks());
			System.out.println(totalAmount);
		}
		return "Success!";
		
	}

}
