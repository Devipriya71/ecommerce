package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Buyer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int buyerid;
	private String username;
	private String password;
	private String emailid;
	private Long mobile_number;
	private String created_datetime;

	
    public int getBuyerid() {
		return buyerid;
	}
	public void setBuyerid(int buyerid) {
		this.buyerid = buyerid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public Long getMobile_number() {
		return mobile_number;
	}
	public void setMobile_number(Long mobile_number) {
		this.mobile_number = mobile_number;
	}
	public String getCreated_datetime() {
		return created_datetime;
	}
	public void setCreated_datetime(String created_datetime) {
		this.created_datetime = created_datetime;
	}
	
	
	public Buyer()
	{
		System.out.println("Buyer Object Has been Created");
	}
	
	public Buyer(int buyerid, String username, String password, String emailid, Long mobile_number,
			String created_datetime) {
		super();
		this.buyerid = buyerid;
		this.username = username;
		this.password = password;
		this.emailid = emailid;
		this.mobile_number = mobile_number;
		this.created_datetime = created_datetime;
		
	}
	
	@Override
	public String toString() {
		return "Buyer [buyerid=" + buyerid + ", username=" + username + ", password=" + password + ", emailid="
				+ emailid + ", mobile_number=" + mobile_number + ", created_datetime=" + created_datetime + "]";
	}
	
	

}

