package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.example.demo.dao.CartDao;
import com.example.demo.dao.ProductDao;
import com.example.demo.dao.PurchaseHistoryDao;
import com.example.demo.dao.TransactionDao;
import com.example.demo.dao.UserDao;
import com.example.demo.entity.Buyer;
import com.example.demo.entity.PurchaseHistory;
import com.example.demo.entity.ShoppingCart;
import com.example.demo.entity.Transactions;

@Service
public class CartService {
	
	@Autowired
	public CartDao cdao;
	@Autowired
	public UserDao udao;
	@Autowired
	public ProductDao prodao;
	@Autowired
	public TransactionDao tdao;
	@Autowired
	public PurchaseHistoryDao pdao;
	
	public String addCartItem(int buyerid,ShoppingCart cart)
	{
		Buyer br=udao.getOne(buyerid);
		cart.setUser(br);
		System.out.println("cart");
		cdao.save(cart);
		
		return "\"Item added\"";
	}
	public List<ShoppingCart> getCart()
	{
		System.out.println("In CartService");
		return cdao.findAll();
	}
	
	public String deleteCartItem(int cart_id)
	{
		cdao.deleteById(cart_id);
		return "\" Item Deleted from the cart\"";
	}

    public String emptyCart(int buyerid)
    {
    	cdao.deleteById(buyerid);
    	return"\"Cart Emptied\"";
    }
    
    public String updateCart(int cid, ShoppingCart scart1,int buid) 
	{
		Buyer br1=udao.getOne(buid);
		ShoppingCart sr=cdao.getOne(cid);
		
		int prid=scart1.getProductid();
		int quantity=scart1.getQuantity();
		float tprice=scart1.getTotal_price();
		
		sr.setProductid(prid);
		sr.setQuantity(quantity);
		sr.setTotal_price(tprice);
		sr.setUser(br1);
		System.out.println(sr);
		cdao.save(sr);
		return "\"Cart item updated\"";
	}
	
    public String checkOut(Transactions transac, int buid) {
		Buyer buyr=udao.getOne(buid);
		System.out.println(buyr);
		transac.setUser(buyr);
		System.out.println(transac);
		tdao.save(transac);
		
		List<ShoppingCart> shcart1=cdao.byid(buid);
		for(int i=0;i<shcart1.size();i++)
		{
			PurchaseHistory phistory=new PurchaseHistory();
			ShoppingCart shcartitems=shcart1.get(i);
			int size=shcartitems.getQuantity();
			phistory.setPurchase_Id(i);
			phistory.setNumber_of_items(size);
			phistory.setUser(buyr);
			System.out.println(shcartitems);
			pdao.save(phistory);
		}
		
		// TODO Auto-generated method stub
		return "Transaction SuccesFull";
	}
    
    public String addPurchase(PurchaseHistory phis) {
		// TODO Auto-generated method stub
		return null;
	}

}

