
import { Component } from '@angular/core';
import { Addcartitem } from './service';
import { Itemsearch } from './Itemsearch';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'App4';
  items:Itemsearch[];
  constructor(private dataService: Addcartitem ) {
    console.log("constructor invoked");
   }

 Addtocart() {
    this.dataService.addItemById(1)
      .subscribe(items =>this.items=items );
  }
 
 
}
