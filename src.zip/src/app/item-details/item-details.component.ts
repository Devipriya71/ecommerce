import { Component, OnInit, Input } from '@angular/core';
import { Itemsearch } from '../Itemsearch';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.css']
})
export class ItemDetailsComponent implements OnInit  {
  @Input() items: Itemsearch[];

  constructor() { 
    console.log("constructor invoked");
   }

   ngOnInit():void {
    
  }

 
}
