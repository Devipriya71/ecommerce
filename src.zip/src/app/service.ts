import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
  })
 /* export class Itemservice 
  { 
    private baseUrl = 'http://localhost:8081/product';

    constructor(private http: HttpClient) { }

    getItemByName(productname:String):Observable<any>
    {   
        console.log("in sevie method");
        return this.http.get(`${this.baseUrl}/getMatchItems/${productname}`);
    }
  }*/

  export class Addcartitem 
  { 
    private baseUrl = 'http://localhost:8081/cart';

    constructor(private http: HttpClient) { }

    addItemById(buyerid:number):Observable<any>
    {   
        
        return this.http.post(`${this.baseUrl}/addItem/${buyerid}`);
        console.log("in service method");
    }
  }