package com.blog.samples.model;

public enum EnumAccountType {

	CURRENT, SAVINGS
}
