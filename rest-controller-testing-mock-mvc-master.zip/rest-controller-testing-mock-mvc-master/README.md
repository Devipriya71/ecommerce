[![Build Status](https://travis-ci.org/briansjavablog/rest-controller-testing-mock-mvc.svg?branch=master)](https://travis-ci.org/briansjavablog/rest-controller-testing-mock-mvc)

# REST Controller Testing WIth MockMVC 
A simple REST controller and some unit tests using Springs MockMVC

The blog post associated with this sample code can be found at https://www.briansdevblog.com/2017/05/rest-endpoint-testing-with-mockmvc
