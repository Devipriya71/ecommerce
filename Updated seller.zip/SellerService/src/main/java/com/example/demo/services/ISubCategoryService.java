package com.example.demo.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.Entity.SubCategory;
@Service
public interface ISubCategoryService {
	
	String addsubcategory(int category_id,SubCategory cat);

	List<SubCategory> getAllSubCategories();

}
