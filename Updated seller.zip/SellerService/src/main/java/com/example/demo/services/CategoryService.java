package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Category;
import com.example.demo.repositry.CategoryDao;
import com.example.demo.repositry.SellerDao;

@Service
public class CategoryService implements ICategoryService {
@Autowired
private CategoryDao catdao;
@Autowired
public SellerDao sdao;

public String addcategory(Category category)
{
	catdao.save(category);
	return "\"Category was added\"";
}
	@Override
	public List<Category> getAllCatogeris() {
		
		return catdao.findAll();
	}

}
