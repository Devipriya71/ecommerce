package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Product;
import com.example.demo.Entity.SellerDetails;
import com.example.demo.repositry.ProductDao;
import com.example.demo.repositry.SellerDao;

@Service
public class ProductService implements IProductService
{
    @Autowired
    private ProductDao pdao;
    @Autowired
    private SellerDao sdao;
    

	public String addProduct(int sellerid, Product prodetails) 
	{     
		SellerDetails sdetails=sdao.getOne(sellerid);
		System.out.println(sdetails);
		prodetails.setSdetails(sdetails);
		pdao.save(prodetails);
		return "Product added";
	}

	@Override
	public void deleteProduct(int prodid, int sellerid) {
		pdao.deleteProduct(prodid,sellerid);
		
		
	}

	@Override
	public void updateProduct(Product pdetails, int sellerid, int prodid) {
		Product productdtails=pdao.getbyid(sellerid, prodid);
		System.out.println(pdetails);
		float cost=pdetails.getPrice();
		int size=pdetails.getQuantity();
		productdtails.setPrice(cost);
		productdtails.setQuantity(size);
		System.out.println(productdtails);
		pdao.save(productdtails);
		
		
	}
     
	
}
