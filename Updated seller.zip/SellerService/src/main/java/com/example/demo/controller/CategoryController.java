package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Category;
import com.example.demo.services.ICategoryService;



@RestController
@RequestMapping("/category")
public class CategoryController {
	@Autowired
	private ICategoryService icatserv;
	
	
	@PostMapping("/addcategory")
	public String addcategory(@RequestBody Category category)
	{
		return icatserv.addcategory(category);
	}
  @GetMapping("/getAllCatogeries")
  public List<Category> getAllCatogeries()
   {
	return icatserv.getAllCatogeris();
   }



}
