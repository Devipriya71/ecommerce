package com.sellerservice.service;

import java.util.List;

import org.springframework.stereotype.Service;


import com.sellerservice.entity.Items;
import com.sellerservice.entity.Seller;
@Service
public interface Iseller {
	
	
	//Seller Service
	
	List<Seller> getAll();
	Seller add(Seller seller);
	Seller getUser(int id);
	Seller updateSeller(Seller seller,int id);
	
	
	
	// Items Service
	
	List<Items> getAllItems();
	Items addItems(Items items);
	Items getProduct(int id);
	Items updateItems(Items items,int id);
	void deleteById(Integer itemId);
	List<Items> searchByName(String itemName);
	List<Items> findByItemName(String itemName);
	

}
