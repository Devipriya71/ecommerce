package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.BuyerDao;
import com.example.demo.dao.ProductDao;


import com.example.demo.entity.Buyer;
import com.example.demo.entity.Product;

@Service
public class BuyerService {
	
	
	

	@Autowired
	public ProductDao pdao;
	@Autowired
	public BuyerDao bdao;
	
	public List<Product> getAllProducts()
	{
		
		return  pdao.findAll();
	}
	public String addBuyer(Buyer buyer) {
		
		 bdao.save( buyer);
		return "/Buyer Added/";
	}

	public List<Buyer> getBuyers() {
		
		return bdao.findAll();
	}
	public String findById(int buyerid) {
		bdao.deleteById(buyerid);
		return "/Buyer Deleted/";
	}
	

}

