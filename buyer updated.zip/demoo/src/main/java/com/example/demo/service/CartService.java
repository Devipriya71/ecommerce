package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.BuyerDao;
import com.example.demo.dao.CartDao;
import com.example.demo.dao.ProductDao;
import com.example.demo.dao.PurchaseHistoryDao;
import com.example.demo.dao.TransactionDao;

import com.example.demo.entity.Buyer;
import com.example.demo.entity.PurchaseHistory;
import com.example.demo.entity.ShoppingCart;
import com.example.demo.entity.Transactions;

@Service
public class CartService {
	
	@Autowired
	public CartDao cdao;
	@Autowired
	public BuyerDao bdao;
	@Autowired
	public ProductDao prodao;
	@Autowired
	public TransactionDao tdao;
	@Autowired
	public PurchaseHistoryDao pdao;
	
	public String addCartItem(int buyerid,ShoppingCart cart)
	{
		Buyer buyer=bdao.getOne(buyerid);
		cart.setUser(buyer);
		System.out.println("cart");
		cdao.save(cart);
		
		return "\"Item added\"";
	}
	public List<ShoppingCart> getCart()
	{
		System.out.println("In CartService");
		return cdao.findAll();
	}
	
	public String deleteCartItem(int cart_id)
	{
		cdao.deleteById(cart_id);
		return "\" Item Deleted from the cart\"";
	}

    public void emptyCart(int burid)
    {
    	cdao.emptyCart(burid);
    	
    }
    
    public String updateCart(int cartid, ShoppingCart cart,int buyerid) 
	{
		Buyer buyer=bdao.getOne(buyerid);
		ShoppingCart sc=cdao.getOne(cartid);
		
		int productid=cart.getProductid();
		int quantity=cart.getQuantity();
		float price=cart.getTotal_price();
		
		sc.setProductid(productid);
		sc.setQuantity(quantity);
		sc.setTotal_price(price);
		sc.setUser(buyer);
		System.out.println(sc);
		cdao.save(sc);
		return "\"Cart item updated\"";
	}
	
    public String checkOut(Transactions transaction, int buyerid) {
		Buyer buyer=bdao.getOne(buyerid);
		System.out.println(buyer);
		transaction.setUser(buyer);
		System.out.println(transaction);
		tdao.save(transaction);
		
		List<ShoppingCart> shoppingcart=cdao.byid(buyerid);
		for(int i=0;i<shoppingcart.size();i++)
		{
			PurchaseHistory purchasehistory=new PurchaseHistory();
			ShoppingCart shoppingcartitems=shoppingcart.get(i);
			int size=shoppingcartitems.getQuantity();
			purchasehistory.setPurchase_Id(i);
			purchasehistory.setNumber_of_items(size);
			purchasehistory.setUser(buyer);
			System.out.println(shoppingcartitems);
			pdao.save(purchasehistory);
		}
		
		// TODO Auto-generated method stub
		return "Transaction SuccesFull";
	}
    
    public String addPurchase(PurchaseHistory phis) {
		// TODO Auto-generated method stub
		return null;
	}

}

