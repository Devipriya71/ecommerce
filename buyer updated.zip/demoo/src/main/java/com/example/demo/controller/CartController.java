package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.PurchaseHistory;
import com.example.demo.entity.ShoppingCart;
import com.example.demo.entity.Transactions;
import com.example.demo.service.BuyerService;
import com.example.demo.service.CartService;

@RestController
@RequestMapping("/cart")
public class CartController {
	@Autowired
	public BuyerService buyerservice;
	@Autowired
	public CartService cartservice;
	

	@PostMapping("/addCartItem/{id}")
	public String addCartItem( @PathVariable ("id") int buyerid,@RequestBody ShoppingCart cart)
	{
		return cartservice.addCartItem(buyerid,cart);
	}
	
	
	@GetMapping("/getCartItems")
	public List<ShoppingCart> getCart()
	{
		//System.out.println("add");
		return cartservice.getCart();
	}
	
	@DeleteMapping("/deleteCartItem/{id}")
	public String deleteCartItem(@PathVariable ("id") int cart_id)
	{
		cartservice.deleteCartItem(cart_id);
		return "\" Item was deleted from the cart\"";
	}
	
	@DeleteMapping("/emptyCart/{id}")
	public void emptyCart(@PathVariable ("id") int burid)
	{
		cartservice.emptyCart(burid);
	
	}
	
	@PostMapping("/updateCartItem/{id}/{bid}")
	public String updateCart(@PathVariable("id") int cartid,@RequestBody ShoppingCart cart,@PathVariable("bid")int buyerid)
	{
		return cartservice.updateCart(cartid,cart,buyerid);
	}
	
	@PostMapping("/checkout/{bids}")
	public String checkOut(@RequestBody Transactions transaction,@PathVariable("bids") int buyerid)
	{
		return cartservice.checkOut(transaction,buyerid);
	}
	
	@PostMapping("/addPurchasehistory")
	public String addPurchase(@RequestBody PurchaseHistory purchasehistory)
	{
		return cartservice.addPurchase(purchasehistory);
	}

}