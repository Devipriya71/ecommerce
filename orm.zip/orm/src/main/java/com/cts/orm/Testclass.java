package com.cts.orm;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.metamodel.Metadata;
import org.hibernate.metamodel.MetadataSources;

public class Testclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration configuration=new Configuration().configure();
        StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties());
        SessionFactory factory = configuration.buildSessionFactory(builder.build());
        Session session = factory.openSession();
        session.beginTransaction();
		Employee e=new Employee();
		e.setEmpId(111);
		e.setEmpname("Ajay");
		e.setDesig("programmer");
		session.save(e);
		session.getTransaction().commit();
		//session.evict(e);
    	//e.setDesig("updated123");
    	//session.save(e); // constraint violation in PK
    	//session.update(e);
    	//session.flush();
   // 	session.flush();
       	//session.getTransaction().commit();
        
    	session.delete(e);
    	session.flush();
    	session.getTransaction().commit();
		session.close();
		
				
		/*
		 * Employee e=(Employee)session.get(Employee.class,1005); //Employee e1=new
		 * Employee(111,"Ajay","programmer"); System.out.println(e);
		 */
		

	}

}
